from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, BooleanField, DateField, SelectField, PasswordField
from wtforms.validators import DataRequired, Length


class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')


class StudentForm(FlaskForm):
    roll = StringField('Roll', validators=[DataRequired(), Length(max=20)])
    name = StringField('Name', validators=[DataRequired(), Length(max=120)])
    clazz = StringField('Class')
    notes = StringField('Notes')
    submit = SubmitField('Save')


class AttendanceForm(FlaskForm):
    date = DateField('Date', validators=[DataRequired()])
    submit = SubmitField('Save')